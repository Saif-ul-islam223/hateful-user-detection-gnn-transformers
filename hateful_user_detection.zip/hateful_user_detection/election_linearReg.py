

import pandas as pd
import re
import string
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics import accuracy_score, precision_recall_fscore_support, accuracy_score


data_path = r"C:\Users\islam\Downloads\GrimmingerKlingerWASSA2021\train.tsv"
df = pd.read_csv(data_path, sep='\t', encoding='utf-8')

def clean_text(text):
    """Lowercase and remove links, mentions, numbers, and punctuation."""
    text = text.lower()
    text = re.sub(r"http\S+|www\S+", "", text)
    text = re.sub(r"@\w+|#", "", text)
    text = re.sub(r"\d+", "", text)
    text = text.translate(str.maketrans("", "", string.punctuation))
    return text.strip()

df["clean_text"] = df["text"].apply(clean_text)
df["label"] = df["HOF"].map({"Hateful": 1, "Non-Hateful": 0})


X_train, X_test, y_train, y_test = train_test_split(
    df["clean_text"], df["label"],
    test_size=0.2,
    random_state=42,
    stratify=df["label"]
)

pipeline = Pipeline([
    ("tfidf", TfidfVectorizer(max_features=8000, ngram_range=(1, 2), stop_words="english")),
    ("regressor", LinearRegression())
])

print("Training Linear Regression model...")
pipeline.fit(X_train, y_train)
print("Training complete!\n")

y_scores = pipeline.predict(X_test)

y_pred = (y_scores >= 0.5).astype(int)

precision, recall, f1, _ = precision_recall_fscore_support(
    y_test, y_pred, labels=[1], average=None
)


accuracy = accuracy_score(y_test, y_pred)

print("Performance on predicting hateful comments:")
print(f"Precision: {precision[0]:.3f}")
print(f"Recall:    {recall[0]:.3f}")
print(f"F1 Score:  {f1[0]:.3f}")
print(f"Accuracy:  {accuracy:.3f}")


