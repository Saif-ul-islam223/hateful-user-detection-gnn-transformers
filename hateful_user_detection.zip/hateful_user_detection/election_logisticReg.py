

import pandas as pd
import re
import string
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics import (
    precision_recall_fscore_support,
    accuracy_score,
    roc_auc_score,
    roc_curve
)

# Load dataset
data_path = r"C:\Users\islam\Downloads\GrimmingerKlingerWASSA2021\train.tsv"
df = pd.read_csv(data_path, sep='\t', encoding='utf-8')

# Clean text
def clean_text(text):
    text = text.lower()
    text = re.sub(r"http\S+|www\S+", "", text)
    text = re.sub(r"@\w+|#", "", text)
    text = re.sub(r"\d+", "", text)
    text = text.translate(str.maketrans("", "", string.punctuation))
    return text.strip()

df["clean_text"] = df["text"].apply(clean_text)
df["label"] = df["HOF"].map({"Hateful": 1, "Non-Hateful": 0})

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(
    df["clean_text"], df["label"],
    test_size=0.2,
    random_state=42,
    stratify=df["label"]
)

# TF-IDF + Logistic Regression pipeline
pipeline = Pipeline([
    ("tfidf", TfidfVectorizer(max_features=8000, ngram_range=(1, 2), stop_words="english")),
    ("logreg", LogisticRegression(class_weight="balanced", max_iter=1000))
])

print("Training Logistic Regression model...")
pipeline.fit(X_train, y_train)
print("Training complete!\n")

# Predict probabilities + labels
y_probs = pipeline.predict_proba(X_test)[:, 1]
y_pred = (y_probs >= 0.5).astype(int)

# Metrics
precision, recall, f1, _ = precision_recall_fscore_support(
    y_test, y_pred, labels=[1], average=None
)
accuracy = accuracy_score(y_test, y_pred)
roc_auc = roc_auc_score(y_test, y_probs)

print("Performance on predicting hateful comments:")
print(f"Precision: {precision[0]:.3f}")
print(f"Recall:    {recall[0]:.3f}")
print(f"F1 Score:  {f1[0]:.3f}")
print(f"Accuracy:  {accuracy:.3f}")
print(f"ROC-AUC:   {roc_auc:.3f}")

# ---- ROC Curve ----
fpr, tpr, thresholds = roc_curve(y_test, y_probs)

plt.figure(figsize=(6, 5))
plt.plot(fpr, tpr, label=f"ROC Curve (AUC = {roc_auc:.3f})")
plt.plot([0, 1], [0, 1], 'k--', label="Random Classifier")
plt.xlabel("False Positive Rate")
plt.ylabel("True Positive Rate")
plt.title("ROC Curve Logistic regression")
plt.legend()
plt.grid(True)
plt.show()



