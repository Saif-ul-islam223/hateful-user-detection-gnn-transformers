import pandas as pd
import re
import string
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import precision_recall_fscore_support, accuracy_score
from transformers import AutoTokenizer, AutoModel
import torch

# Load dataset
data_path = r"C:\Users\islam\Downloads\archive\labeled_data.csv"
df = pd.read_csv(data_path, sep=",", encoding="latin-1")

# Clean text
def clean_text(text):
    text = text.lower()
    text = re.sub(r"http\S+|www\S+", "", text)
    text = re.sub(r"@\w+|#", "", text)
    text = re.sub(r"\d+", "", text)
    text = text.translate(str.maketrans("", "", string.punctuation))
    return text.strip()

df["clean_text"] = df["tweet"].apply(clean_text)

# Correct label mapping
df["label"] = df["class"]

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(
    df["clean_text"], df["label"],
    test_size=0.2,
    random_state=42,
    stratify=df["label"]
)


tokenizer = AutoTokenizer.from_pretrained("bert-base-uncased")
model = AutoModel.from_pretrained("bert-base-uncased")
model.eval()


def get_batch_embeddings(text_list, batch_size=16):
    all_embeddings = []

    for i in range(0, len(text_list), batch_size):
        batch = text_list[i:i+batch_size]
        inputs = tokenizer(
            batch,
            return_tensors="pt",
            truncation=True,
            padding=True,
            max_length=128
        )

        with torch.no_grad():
            outputs = model(**inputs)

        cls_embeddings = outputs.last_hidden_state[:, 0, :].numpy()
        all_embeddings.append(cls_embeddings)

    return np.vstack(all_embeddings)

# Generate embeddings
X_train_embeddings = get_batch_embeddings(list(X_train))
X_test_embeddings = get_batch_embeddings(list(X_test))

# Train classifier
clf = LogisticRegression(max_iter=2000)
clf.fit(X_train_embeddings, y_train)

# Evaluate
y_pred = clf.predict(X_test_embeddings)

precision, recall, f1, _ = precision_recall_fscore_support(y_test, y_pred, average='weighted')
accuracy = accuracy_score(y_test, y_pred)

print(f"Precision: {precision:.4f}")
print(f"Recall: {recall:.4f}")
print(f"F1-score: {f1:.4f}")
print(f"Accuracy: {accuracy:.4f}")


