import pandas as pd
import re
import string
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics import precision_recall_fscore_support, accuracy_score

data_path = r"C:\Users\islam\Downloads\GrimmingerKlingerWASSA2021\train.tsv"
df = pd.read_csv(data_path, sep='\t', encoding='utf-8')

def clean_text(text):
    text = text.lower()
    text = re.sub(r"http\S+|www\S+", "", text)
    text = re.sub(r"@\w+|#", "", text)
    text = re.sub(r"\d+", "", text)
    text = text.translate(str.maketrans("", "", string.punctuation))
    return text.strip()

df["clean_text"] = df["text"].apply(clean_text)
df["label"] = df["HOF"].map({"Hateful": 1, "Non-Hateful": 0})

X_train, X_test, y_train, y_test = train_test_split(
    df["clean_text"], df["label"],
    test_size=0.2,
    random_state=42,
    stratify=df["label"]
)

pipeline = Pipeline([
    ("tfidf", TfidfVectorizer(max_features=8000, ngram_range=(1, 2), stop_words="english")),
    ("rf", RandomForestClassifier(n_estimators=200, class_weight="balanced", random_state=42))
])

pipeline.fit(X_train, y_train)

y_probs = pipeline.predict_proba(X_test)[:, 1]
y_pred = (y_probs >= 0.5).astype(int)

precision, recall, f1, _ = precision_recall_fscore_support(y_test, y_pred, labels=[1], average=None)
acc = accuracy_score(y_test, y_pred)

print("Performance on hateful comments:")
print(f"Precision: {precision[0]:.3f}")
print(f"Recall:    {recall[0]:.3f}")
print(f"F1 Score:  {f1[0]:.3f}")
print(f"Accuracy:  {acc:.3f}")


